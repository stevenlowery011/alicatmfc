# Alicat mass flow controller python package

This is a package for controlling Alicat mass flow controllers with Python. 