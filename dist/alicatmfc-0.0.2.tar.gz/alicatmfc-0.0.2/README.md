# Alicat mass flow controller python package

This is a package for controlling Alicat mass flow controllers with Python. 

This is a basic package. A better version exists with more features here: https://github.com/numat/alicat
